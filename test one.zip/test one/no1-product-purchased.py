product1 = input("Enter the first product name: ")
product1_price = float(input(f"Enter the price of {product1}: "))

product2 = input("Enter the second product name: ")
product2_price = float(input(f"Enter the price of {product2}: "))

product3 = input("Enter the third product name: ")
product3_price = float(input(f"Enter the price of {product3}: "))


total_price = product1_price + product2_price + product3_price
average_price = total_price / 3

print("\nSummary of Purchase:")
print(f"{product1}: ${product1_price:.2f}")
print(f"{product2}: ${product2_price:.2f}")
print(f"{product3}: ${product3_price:.2f}")
print(f"\nTotal Price: ${total_price:.2f}")
print(f"Average Price: ${average_price:.2f}")