def calculate_final_mark(warmup1, warmup2, warmup3, test1):
    average_warmups = (warmup1 + warmup2 + warmup3) / 3
    final_mark = (average_warmups + test1) / 2
    return final_mark

name = input("Enter your Name: ")
age = int(input("Enter your Age: "))
address = input("Enter your Address: ")
course = input("Enter your Course: ")
student_number = input("Enter your Student Number: ")
gender = input("Enter your Gender: ")
weight = float(input("Enter your Weight (kg): "))

warmup1 = float(input("Enter Warm-up 1 Marks: "))
warmup2 = float(input("Enter Warm-up 2 Marks: "))
warmup3 = float(input("Enter Warm-up 3 Marks: "))
test1 = float(input("Enter Test 1 Marks: "))

final_coursework_mark = calculate_final_mark(warmup1, warmup2, warmup3, test1)

print("\n*****Student Biodata *****")
print(f"Name: {name}")
print(f"Age: {age}")
print(f"Address: {address}")
print(f"Course: {course}")
print(f"Student Number: {student_number}")
print(f"Gender: {gender}")
print(f"Weight: {weight} kg")

print("\n**** Coursework Marks ****")
print(f"Warm-up 1: {warmup1}")
print(f"Warm-up 2: {warmup2}")
print(f"Warm-up 3: {warmup3}")
print(f"Test 1: {test1}")
print(f"Final Coursework Mark: {final_coursework_mark:.2f}")
