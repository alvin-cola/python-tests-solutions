import math


def calculate_distance(x1, x2, y1, y2):
    d = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
    return d

x1 = float(input("Enter X1: "))
x2 = float(input("Enter X2: "))
y1 = float(input("Enter Y1: "))
y2 = float(input("Enter Y2: "))

distance = calculate_distance(x1, x2, y1, y2)
print(f"\nThe distance (d) between the two points is: {distance:.2f}")
